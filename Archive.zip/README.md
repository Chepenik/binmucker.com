# binmucker.com
A repository for my Dad Blog

I'm also a proffesional shit poster on Nostr if you would like to follow me there. 
It's quite empowering when you enter a network architecture of smart clients and dumb servers. 
I've very much been enjoying the vale4value model zaps enable. Once you get zapped satoshis (small units of bitcoin) for quality content... 
well good luck going back to the old paradigm of smart servers and dumb clients. 

Information yearns to be free. Few https://primal.net/profile/npub16syt2k5uky4pxycfttxrxmwwzht2t3008f2q68kw4almjl4guu9qea8t7y
